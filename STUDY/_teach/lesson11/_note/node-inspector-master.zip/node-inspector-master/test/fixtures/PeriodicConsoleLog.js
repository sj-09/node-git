var a = 0;
console.log(a);
setInterval(function(){
  console.log(++a);
}, 1000);
