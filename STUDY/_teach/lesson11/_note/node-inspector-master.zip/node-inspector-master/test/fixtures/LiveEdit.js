/*jshint debug:true */
process.stdin.once('data', function() {
  debugger;
});
